# NewsApp_UsingJava

_by Harsh Goyal_

**API KEY -** https://content.guardianapis.com/search?q=science&api-key=test&show-fields=thumbnail

In this android application you can search your latest news as according to your preferences. When you click news item it will redirect to the actual page of the news.

Here are some screenshots of the applications that you can relate with them:

**1. Main activity screen-**

<img src="https://user-images.githubusercontent.com/79085857/136683562-eeeebe6b-add4-4c0b-a2d3-50c6636bc74c.jpg" width="280" height="500">

**2. Settings activity screen-**

<img src="https://user-images.githubusercontent.com/79085857/136683871-0a6b17fa-83cf-441c-b478-93e38e949e05.jpg" width="280" height="500">

**3. Settings activity screen preferences-**

<img src="https://user-images.githubusercontent.com/79085857/136684113-07750758-564c-4994-92cc-08d3b758be0d.jpg" width="280" height="500">
<img src="https://user-images.githubusercontent.com/79085857/136684191-58ab99f3-eb86-4350-89c2-985bb28aa8f1.jpg" width="280" height="500">
<img src="https://user-images.githubusercontent.com/79085857/136684144-3baa48e3-d6ed-4eb1-86cd-195913f84cce.jpg" width="280" height="500">
